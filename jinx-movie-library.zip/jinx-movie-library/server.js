require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB) || 2048;
const ADMIN_NAME = process.env.ADMIN_NAME || 'Innocent Ainebyona';
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const GENRES = ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama',
  'Family', 'Fantasy', 'Horror', 'Music', 'Mystery', 'Romance', 'Sci-Fi', 'Thriller', 'War', 'Western', 'Other'];

let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET === 'change-me') {
  if (IS_PROD) { console.error('FATAL: set a strong JWT_SECRET in production.'); process.exit(1); }
  JWT_SECRET = crypto.randomBytes(32).toString('hex');
  console.warn('JWT_SECRET not set: using a temporary one (logins reset on restart).');
}

const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, 'uploads'));
const VIDEO_DIR = path.join(UPLOAD_DIR, 'videos');
const POSTER_DIR = path.join(UPLOAD_DIR, 'posters');
fs.mkdirSync(VIDEO_DIR, { recursive: true });
fs.mkdirSync(POSTER_DIR, { recursive: true });

if (!ADMIN_EMAIL) console.warn('WARNING: ADMIN_EMAIL is not set. Nobody can be admin or approve uploaders.');
else {
  // Only the ADMIN_EMAIL account is admin. Everyone else is demoted if needed.
  db.prepare("UPDATE users SET role = 'admin' WHERE email = ?").run(ADMIN_EMAIL);
  db.prepare("UPDATE users SET role = 'viewer' WHERE role = 'admin' AND email != ?").run(ADMIN_EMAIL);
}

const app = express();
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'style-src': ["'self'", 'https://fonts.googleapis.com'],
      'font-src': ["'self'", 'https://fonts.gstatic.com'],
      'img-src': ["'self'", 'data:'],
      'media-src': ["'self'", 'blob:'],
      'connect-src': ["'self'"],
      'upgrade-insecure-requests': null
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(compression());
app.use(express.json({ limit: '50kb' }));

const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 600, standardHeaders: true, legacyHeaders: false });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 25, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many attempts. Try again in a few minutes.' } });
app.use('/api', apiLimiter);

// ---------- helpers ----------
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const signToken = u => jwt.sign({ id: u.id, role: u.role }, JWT_SECRET, { expiresIn: '14d' });
const publicUser = u => ({ id: u.id, name: u.name, email: u.email, role: u.role, canUpload: canUpload(u), uploadRequested: !!u.upload_requested });
const canUpload = u => u.role === 'admin' || u.role === 'uploader';

function auth(required = true) {
  return (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return required ? res.status(401).json({ error: 'Please sign in.' }) : next();
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.id);
      if (!user) throw new Error('no user');
      req.user = user;
      next();
    } catch {
      if (required) return res.status(401).json({ error: 'Session expired. Please sign in again.' });
      next();
    }
  };
}

const movieJson = m => ({
  id: m.id,
  title: m.title,
  description: m.description,
  genre: m.genre,
  year: m.year,
  views: m.views,
  createdAt: m.created_at,
  uploader: m.uploader_name,
  uploaderId: m.user_id,
  posterUrl: m.poster_file ? `/media/posters/${m.poster_file}` : null,
  videoUrl: `/media/videos/${m.video_file}`
});

const MOVIE_SELECT = `SELECT m.*, u.name AS uploader_name FROM movies m JOIN users u ON u.id = m.user_id`;

// ---------- upload handling ----------
const VIDEO_TYPES = { '.mp4': 'video/mp4', '.webm': 'video/webm', '.ogv': 'video/ogg', '.mov': 'video/quicktime', '.m4v': 'video/x-m4v' };
const IMAGE_TYPES = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp' };

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, file.fieldname === 'video' ? VIDEO_DIR : POSTER_DIR),
    filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + path.extname(file.originalname).toLowerCase())
  }),
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 2, fields: 10 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const ok = file.fieldname === 'video'
      ? ext in VIDEO_TYPES && file.mimetype.startsWith('video/')
      : file.fieldname === 'poster' && ext in IMAGE_TYPES && file.mimetype.startsWith('image/');
    cb(ok ? null : new Error(file.fieldname === 'video'
      ? 'Video must be MP4, WebM, OGV, MOV or M4V.' : 'Poster must be a JPG, PNG or WebP image.'), ok);
  }
}).fields([{ name: 'video', maxCount: 1 }, { name: 'poster', maxCount: 1 }]);

const removeFile = (dir, name) => { if (name) fs.unlink(path.join(dir, name), () => {}); };
const cleanupUploads = files => {
  (files?.video || []).forEach(f => removeFile(VIDEO_DIR, f.filename));
  (files?.poster || []).forEach(f => removeFile(POSTER_DIR, f.filename));
};

// ---------- auth routes ----------
app.get('/api/config', (req, res) => res.json({ genres: GENRES, maxUploadMb: MAX_UPLOAD_MB, adminName: ADMIN_NAME }));

app.post('/api/auth/register', authLimiter, wrap(async (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (name.length < 2 || name.length > 50) return res.status(400).json({ error: 'Name must be 2 to 50 characters.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) return res.status(409).json({ error: 'That email is already registered.' });

  // Only ADMIN_EMAIL can ever be admin.
  const isFirst = !!ADMIN_EMAIL && email === ADMIN_EMAIL;
  const hash = await bcrypt.hash(password, 12);
  const info = db.prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)')
    .run(name, email, hash, isFirst ? 'admin' : 'viewer');
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ token: signToken(user), user: publicUser(user) });
}));

app.post('/api/auth/login', authLimiter, wrap(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  const ok = user && await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Incorrect email or password.' });
  res.json({ token: signToken(user), user: publicUser(user) });
}));

app.get('/api/auth/me', auth(), (req, res) => res.json({ user: publicUser(req.user) }));

// ---------- movie routes ----------
app.get('/api/movies', (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 100);
  const genre = String(req.query.genre || '');
  const sort = String(req.query.sort || 'new');
  const mine = req.query.mine === '1';
  const limit = Math.min(Math.max(parseInt(req.query.limit) || 24, 1), 60);
  const page = Math.max(parseInt(req.query.page) || 1, 1);
  const exclude = parseInt(req.query.exclude) || 0;

  const where = [], params = [];
  if (q) { where.push('(m.title LIKE ? ESCAPE \'\\\' OR m.description LIKE ? ESCAPE \'\\\')');
    const like = `%${q.replace(/[\\%_]/g, '\\$&')}%`; params.push(like, like); }
  if (genre && GENRES.includes(genre)) { where.push('m.genre = ?'); params.push(genre); }
  if (exclude) { where.push('m.id != ?'); params.push(exclude); }
  if (mine) {
    // optional auth for "mine"
    const header = req.headers.authorization || '';
    try {
      const p = jwt.verify(header.slice(7), JWT_SECRET);
      where.push('m.user_id = ?'); params.push(p.id);
    } catch { return res.status(401).json({ error: 'Please sign in.' }); }
  }
  const order = { new: 'm.created_at DESC, m.id DESC', popular: 'm.views DESC, m.id DESC', title: 'm.title COLLATE NOCASE ASC' }[sort]
    || 'm.created_at DESC, m.id DESC';
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';

  const total = db.prepare(`SELECT COUNT(*) AS c FROM movies m ${whereSql}`).get(...params).c;
  const rows = db.prepare(`${MOVIE_SELECT} ${whereSql} ORDER BY ${order} LIMIT ? OFFSET ?`)
    .all(...params, limit, (page - 1) * limit);
  res.json({ movies: rows.map(movieJson), total, page, pages: Math.max(Math.ceil(total / limit), 1) });
});

app.get('/api/movies/:id', (req, res) => {
  const m = db.prepare(`${MOVIE_SELECT} WHERE m.id = ?`).get(req.params.id);
  if (!m) return res.status(404).json({ error: 'Movie not found.' });
  res.json({ movie: movieJson(m) });
});

app.post('/api/movies/:id/view', (req, res) => {
  db.prepare('UPDATE movies SET views = views + 1 WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

app.post('/api/movies', auth(), (req, res, next) => {
  if (!canUpload(req.user)) return res.status(403).json({ error: 'Your account cannot upload movies.' });
  upload(req, res, err => {
    if (err) {
      cleanupUploads(req.files);
      const msg = err.code === 'LIMIT_FILE_SIZE' ? `File is too large. Limit is ${MAX_UPLOAD_MB} MB.` : err.message;
      return res.status(400).json({ error: msg });
    }
    try {
      const title = String(req.body.title || '').trim();
      const description = String(req.body.description || '').trim();
      const genre = String(req.body.genre || '');
      const year = req.body.year ? parseInt(req.body.year) : null;
      const video = req.files?.video?.[0];
      const poster = req.files?.poster?.[0];

      const fail = msg => { cleanupUploads(req.files); return res.status(400).json({ error: msg }); };
      if (!video) return fail('Choose a video file to upload.');
      if (!title || title.length > 120) return fail('Title is required (120 characters max).');
      if (description.length > 2000) return fail('Description is too long (2000 characters max).');
      if (!GENRES.includes(genre)) return fail('Pick a genre.');
      if (year !== null && (year < 1888 || year > new Date().getFullYear() + 1)) return fail('Enter a valid release year.');

      const info = db.prepare(`INSERT INTO movies (title, description, genre, year, video_file, poster_file, user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?)`).run(title, description, genre, year, video.filename, poster?.filename || null, req.user.id);
      const m = db.prepare(`${MOVIE_SELECT} WHERE m.id = ?`).get(info.lastInsertRowid);
      res.status(201).json({ movie: movieJson(m) });
    } catch (e) { cleanupUploads(req.files); next(e); }
  });
});

app.delete('/api/movies/:id', auth(), (req, res) => {
  const m = db.prepare('SELECT * FROM movies WHERE id = ?').get(req.params.id);
  if (!m) return res.status(404).json({ error: 'Movie not found.' });
  if (m.user_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'You can only delete your own uploads.' });
  db.prepare('DELETE FROM movies WHERE id = ?').run(m.id);
  removeFile(VIDEO_DIR, m.video_file);
  removeFile(POSTER_DIR, m.poster_file);
  res.json({ ok: true });
});

// ---------- admin: approve upload authority ----------
const adminOnly = (req, res, next) =>
  req.user.role === 'admin' && req.user.email.toLowerCase() === ADMIN_EMAIL
    ? next() : res.status(403).json({ error: 'Only the administrator can do this.' });

app.post('/api/me/request-upload', auth(), (req, res) => {
  if (canUpload(req.user)) return res.json({ ok: true });
  db.prepare('UPDATE users SET upload_requested = 1 WHERE id = ?').run(req.user.id);
  res.json({ ok: true });
});

app.get('/api/admin/users', auth(), adminOnly, (req, res) => {
  const users = db.prepare(`SELECT id, name, email, role, upload_requested, created_at FROM users
    ORDER BY upload_requested DESC, created_at DESC`).all();
  res.json({ users: users.map(u => ({ id: u.id, name: u.name, email: u.email, role: u.role,
    requested: !!u.upload_requested, createdAt: u.created_at })) });
});

app.post('/api/admin/users/:id/role', auth(), adminOnly, (req, res) => {
  const role = String(req.body.role || '');
  if (!['viewer', 'uploader'].includes(role)) return res.status(400).json({ error: 'Role must be viewer or uploader.' });
  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found.' });
  if (target.role === 'admin') return res.status(400).json({ error: 'The administrator cannot be changed.' });
  db.prepare('UPDATE users SET role = ?, upload_requested = 0 WHERE id = ?').run(role, target.id);
  res.json({ ok: true });
});

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

// ---------- media (supports HTTP Range for seeking) ----------
const mediaOpts = { acceptRanges: true, dotfiles: 'ignore', index: false, maxAge: '30d', immutable: true };
app.use('/media/videos', express.static(VIDEO_DIR, mediaOpts));
app.use('/media/posters', express.static(POSTER_DIR, mediaOpts));

// ---------- frontend ----------
app.use(express.static(path.join(__dirname, 'public'), { maxAge: IS_PROD ? '1h' : 0 }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ---------- errors ----------
app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Server error. Please try again.' });
});

app.listen(PORT, () => console.log(`Jinx Movie Library running on http://localhost:${PORT}`));
