# Jinx Movie Library

A self-hosted movie upload and streaming site. Node.js + Express + SQLite on the backend, a no-build vanilla JS single-page app on the front end.

**Features:** accounts (JWT), movie upload with progress bar, poster images, HTTP Range streaming (seek anywhere), search, genre filter, sorting, pagination, view counts, "more to watch", admin-approved uploaders, rate limiting, security headers.

## Run locally

```bash
npm install
cp .env.example .env      # set JWT_SECRET
npm start                 # http://localhost:3000
```

**Administrator: Innocent Ainebyona.** Only the email in `ADMIN_EMAIL` can be admin. Everyone else registers as a viewer. Viewers can tap "Request upload access"; the admin opens **Admin** in the header and approves or removes upload access. Only the admin and approved uploaders can upload movies.

## Deploy with Docker

```bash
cp .env.example .env       # set JWT_SECRET, TRUST_PROXY=1
docker compose up -d --build
```
Data persists in the `jinx-data` volume (database + uploaded files).

## Going live checklist

1. Put it behind HTTPS (Caddy, nginx, Cloudflare, or a PaaS like Railway/Fly/Render with a persistent disk).
2. nginx: set `client_max_body_size 2100m;` and `proxy_request_buffering off;` so big uploads work. Set `TRUST_PROXY=1`.
3. Set a strong `JWT_SECRET`. Back up `DATA_DIR` and `UPLOAD_DIR`.
4. For lots of viewers, serve `/media/` from a CDN or object storage (S3/R2) and consider transcoding to HLS with ffmpeg.
5. Encode uploads as MP4 (H.264 + AAC) so they play in every browser.

## Content and legal

Only host films you own or are licensed to distribute. If you accept public uploads, publish a takedown/contact policy and respond to copyright notices.

## API

| Method | Path | Notes |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | returns `{token,user}` |
| GET | /api/movies | `q, genre, sort=new\|popular\|title, page, limit, mine=1` |
| GET | /api/movies/:id | |
| POST | /api/movies | multipart: `video, poster, title, genre, year, description` |
| DELETE | /api/movies/:id | owner or admin |
| GET | /media/videos/:file | streamable with Range |
