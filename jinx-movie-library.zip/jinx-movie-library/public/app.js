(() => {
  const $main = document.getElementById('main');
  const $top = document.getElementById('top');
  const $toast = document.getElementById('toast');
  const state = { user: null, token: localStorage.getItem('rb_token'), genres: [], maxUploadMb: 2048 };

  // ---------- helpers ----------
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'value') el.value = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(kid));
    }
    return el;
  }

  async function api(path, opts = {}) {
    const headers = { ...(opts.headers || {}) };
    if (state.token) headers.Authorization = 'Bearer ' + state.token;
    let body = opts.body;
    if (opts.json) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch('/api' + path, { method: opts.method || 'GET', headers, body });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (res.status === 401 && state.token) setSession(null, null);
      throw new Error(data.error || 'Something went wrong.');
    }
    return data;
  }

  let toastTimer;
  function toast(msg) {
    $toast.textContent = msg;
    $toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => $toast.classList.remove('show'), 2800);
  }

  function setSession(token, user) {
    state.token = token; state.user = user;
    if (token) localStorage.setItem('rb_token', token); else localStorage.removeItem('rb_token');
    renderHeader();
  }

  const go = hash => { location.hash = hash; };
  const fmtViews = n => `${n.toLocaleString()} ${n === 1 ? 'view' : 'views'}`;
  const fmtDate = s => new Date(s.replace(' ', 'T') + 'Z').toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });

  // ---------- header ----------
  function renderHeader() {
    const q = new URLSearchParams((location.hash.split('?')[1] || '')).get('q') || '';
    const search = h('form', { class: 'search', role: 'search', onsubmit: e => {
      e.preventDefault();
      const v = e.target.q.value.trim();
      go(v ? '#/?q=' + encodeURIComponent(v) : '#/');
    } }, h('input', { name: 'q', type: 'search', placeholder: 'Search movies', 'aria-label': 'Search movies', value: q }));

    const nav = h('nav', { class: 'nav', 'aria-label': 'Account' });
    if (state.user) {
      if (state.user.role === 'admin') nav.append(h('span', { class: 'badge', title: state.user.name }, 'Administrator'));
      if (state.user.canUpload) nav.append(h('a', { class: 'btn primary', href: '#/upload' }, 'Upload movie'));
      if (state.user.canUpload) nav.append(h('a', { class: 'btn', href: '#/mine' }, 'My uploads'));
      if (state.user.role === 'admin') nav.append(h('a', { class: 'btn', href: '#/admin' }, 'Admin'));
      nav.append(h('button', { class: 'btn', onclick: () => { setSession(null, null); toast('Signed out'); go('#/'); } }, 'Sign out'));
    } else {
      nav.append(h('a', { class: 'btn', href: '#/login' }, 'Sign in'));
      nav.append(h('a', { class: 'btn primary', href: '#/register' }, 'Create account'));
    }
    $top.replaceChildren(h('a', { class: 'logo', href: '#/', 'aria-label': 'Jinx Movie Library home' }, h('img', { src: '/logo-128.png', alt: '', width: 44, height: 44 }), h('b', {}, 'JINX'), h('span', {}, 'MOVIE LIBRARY')), search, nav);
  }

  // ---------- shared components ----------
  function movieCard(m) {
    const poster = h('div', { class: 'poster' },
      h('div', { class: 'ph' }, m.title),
      m.posterUrl && h('img', { src: m.posterUrl, alt: '', loading: 'lazy' }));
    return h('a', { class: 'card', href: '#/watch/' + m.id }, poster,
      h('h3', {}, m.title),
      h('div', { class: 'meta' }, [m.year, m.genre].filter(Boolean).join(' • ')));
  }

  const loading = () => $main.replaceChildren(h('p', { class: 'loading' }, 'Loading…'));
  const fail = msg => $main.replaceChildren(h('div', { class: 'empty' }, h('h3', {}, 'Could not load this page'), h('p', {}, msg)));

  // ---------- pages ----------
  async function home(params) {
    const q = params.get('q') || '';
    const genre = params.get('genre') || '';
    const sort = params.get('sort') || 'new';
    const page = parseInt(params.get('page')) || 1;
    loading();

    const qs = new URLSearchParams({ sort, page });
    if (q) qs.set('q', q);
    if (genre) qs.set('genre', genre);
    const [list, top] = await Promise.all([
      api('/movies?' + qs),
      (!q && !genre && page === 1) ? api('/movies?sort=popular&limit=1') : Promise.resolve(null)
    ]);

    const link = (over) => {
      const p = new URLSearchParams({ ...(q && { q }), ...(genre && { genre }), ...(sort !== 'new' && { sort }), ...over });
      [...p].forEach(([k, v]) => { if (!v || (k === 'page' && v === '1')) p.delete(k); });
      return '#/' + (p.toString() ? '?' + p : '');
    };

    const out = [];
    const feat = top?.movies?.[0];
    if (feat) {
      out.push(h('section', { class: 'hero' },
        feat.posterUrl && h('img', { src: feat.posterUrl, alt: '' }),
        h('div', { class: 'hero-body' },
          h('h1', {}, feat.title),
          h('p', {}, feat.description || 'Now streaming.'),
          h('a', { class: 'btn primary', href: '#/watch/' + feat.id }, 'Watch now'))));
    }

    const chips = h('div', { class: 'bar', role: 'group', 'aria-label': 'Genres' },
      h('button', { class: 'chip', 'aria-pressed': String(!genre), onclick: () => go(link({ genre: '', page: '' })) }, 'All'),
      state.genres.map(g => h('button', { class: 'chip', 'aria-pressed': String(genre === g), onclick: () => go(link({ genre: g, page: '' })) }, g)),
      h('select', { class: 'sort', 'aria-label': 'Sort by', onchange: e => go(link({ sort: e.target.value, page: '' })) },
        [['new', 'Newest'], ['popular', 'Most watched'], ['title', 'A to Z']].map(([v, t]) => h('option', { value: v, selected: sort === v }, t))));
    out.push(chips);

    const heading = q ? `Results for “${q}”` : genre ? genre : 'All movies';
    out.push(h('h2', { class: 'sec' }, heading));

    if (!list.movies.length) {
      out.push(h('div', { class: 'empty' }, h('h3', {}, q || genre ? 'No movies match' : 'No movies yet'),
        h('p', {}, q || genre ? 'Try a different search or genre.' :
          (state.user?.canUpload ? 'Upload the first movie to get started.' : 'New movies are added by approved uploaders.')),
        (!q && !genre && state.user?.canUpload) && h('p', {}, h('a', { class: 'btn primary', href: '#/upload' }, 'Upload movie'))));
    } else {
      out.push(h('div', { class: 'grid' }, list.movies.map(movieCard)));
      if (list.pages > 1) {
        out.push(h('div', { class: 'pager' },
          page > 1 && h('a', { class: 'btn', href: link({ page: page - 1 }) }, 'Previous'),
          `Page ${list.page} of ${list.pages}`,
          page < list.pages && h('a', { class: 'btn', href: link({ page: page + 1 }) }, 'Next')));
      }
    }
    $main.replaceChildren(...out);
    document.title = (q || genre ? heading + ' – ' : '') + 'Jinx Movie Library';
  }

  async function mine() {
    if (!state.user) return go('#/login');
    loading();
    const { movies } = await api('/movies?mine=1&limit=60&sort=new');
    $main.replaceChildren(
      h('h2', { class: 'sec' }, 'My uploads'),
      movies.length ? h('div', { class: 'grid' }, movies.map(movieCard))
        : h('div', { class: 'empty' }, h('h3', {}, 'Nothing uploaded yet'),
          h('p', {}, h('a', { class: 'btn primary', href: '#/upload' }, 'Upload movie'))));
    document.title = 'My uploads – Jinx Movie Library';
  }

  async function watch(id) {
    loading();
    const { movie: m } = await api('/movies/' + id);
    const video = h('video', { class: 'player', controls: true, preload: 'metadata', playsinline: true, poster: m.posterUrl || null, src: m.videoUrl });
    let counted = false;
    video.addEventListener('play', () => {
      const key = 'rb_seen_' + m.id;
      if (counted || sessionStorage.getItem(key)) return;
      counted = true; sessionStorage.setItem(key, '1');
      api(`/movies/${m.id}/view`, { method: 'POST' }).catch(() => {});
    });

    const canDelete = state.user && (state.user.id === m.uploaderId || state.user.role === 'admin');
    const side = h('aside', { class: 'side' }, h('h2', { class: 'sec' }, 'More to watch'));
    api(`/movies?genre=${encodeURIComponent(m.genre)}&exclude=${m.id}&limit=6&sort=popular`).then(({ movies }) => {
      if (!movies.length) return side.remove();
      movies.forEach(r => side.append(movieCard(r)));
    }).catch(() => side.remove());

    $main.replaceChildren(h('div', { class: 'watch' },
      h('div', {},
        video,
        h('h1', {}, m.title),
        h('div', { class: 'meta' }, [m.year, m.genre, fmtViews(m.views), 'Added ' + fmtDate(m.createdAt) + ' by ' + m.uploader].filter(Boolean).join(' • ')),
        m.description && h('p', { class: 'desc' }, m.description),
        canDelete && h('div', { class: 'actions' }, h('button', { class: 'btn danger', onclick: async () => {
          if (!confirm('Delete this movie permanently?')) return;
          try { await api('/movies/' + m.id, { method: 'DELETE' }); toast('Movie deleted'); go('#/'); }
          catch (e) { toast(e.message); }
        } }, 'Delete movie'))),
      side));
    document.title = m.title + ' – Jinx Movie Library';
  }

  function authPage(mode) {
    if (state.user) return go('#/');
    const reg = mode === 'register';
    const err = h('p', { class: 'err', role: 'alert' });
    const form = h('form', { onsubmit: async e => {
      e.preventDefault();
      err.textContent = '';
      const btn = form.querySelector('button'); btn.disabled = true;
      const f = new FormData(form);
      try {
        const data = await api('/auth/' + mode, { method: 'POST', json: Object.fromEntries(f) });
        setSession(data.token, data.user);
        toast(reg ? 'Welcome to Jinx Movie Library' : 'Signed in');
        go('#/');
      } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
    } },
      reg && h('div', { class: 'field' }, h('label', { for: 'name' }, 'Name'), h('input', { id: 'name', name: 'name', required: true, autocomplete: 'name' })),
      h('div', { class: 'field' }, h('label', { for: 'email' }, 'Email'), h('input', { id: 'email', name: 'email', type: 'email', required: true, autocomplete: 'email' })),
      h('div', { class: 'field' }, h('label', { for: 'password' }, 'Password'),
        h('input', { id: 'password', name: 'password', type: 'password', required: true, minlength: 8, autocomplete: reg ? 'new-password' : 'current-password' }),
        reg && h('small', {}, 'At least 8 characters.')),
      err,
      h('button', { class: 'btn primary', type: 'submit' }, reg ? 'Create account' : 'Sign in'));
    $main.replaceChildren(h('div', { class: 'panel' }, h('img', { class: 'auth-logo', src: '/logo-512.png', alt: 'Jinx Movie Library', width: 160, height: 160 }), h('h1', {}, reg ? 'Create your account' : 'Sign in'), form,
      h('p', { class: 'switch' }, reg ? 'Already have an account? ' : 'New here? ',
        h('a', { href: reg ? '#/login' : '#/register' }, reg ? 'Sign in' : 'Create an account'))));
    document.title = (reg ? 'Create account' : 'Sign in') + ' – Jinx Movie Library';
    document.getElementById(reg ? 'name' : 'email').focus();
  }

  function uploadPage() {
    if (!state.user) return go('#/login');
    if (!state.user.canUpload) {
      const note = h('p', { class: 'meta' }, state.user.uploadRequested ? 'Request sent. The administrator will review it.' : '');
      const btn = h('button', { class: 'btn primary', disabled: state.user.uploadRequested, onclick: async () => {
        btn.disabled = true;
        try { await api('/me/request-upload', { method: 'POST' }); state.user.uploadRequested = true; note.textContent = 'Request sent. The administrator will review it.'; toast('Request sent'); }
        catch (e) { btn.disabled = false; toast(e.message); }
      } }, 'Request upload access');
      $main.replaceChildren(h('div', { class: 'empty' }, h('h3', {}, 'Uploading needs approval'),
        h('p', {}, 'Only people approved by the administrator can upload movies.'), h('p', {}, btn), note));
      return;
    }
    const err = h('p', { class: 'err', role: 'alert' });
    const bar = h('progress', { max: '100', value: '0', hidden: true, 'aria-label': 'Upload progress' });
    const status = h('p', { class: 'meta' });
    const submit = h('button', { class: 'btn primary', type: 'submit' }, 'Upload movie');
    const thisYear = new Date().getFullYear();

    const form = h('form', { onsubmit: e => {
      e.preventDefault();
      err.textContent = '';
      const fd = new FormData(form);
      if (!fd.get('poster').size) fd.delete('poster');
      const video = fd.get('video');
      if (!video || !video.size) { err.textContent = 'Choose a video file.'; return; }
      if (video.size > state.maxUploadMb * 1024 * 1024) { err.textContent = `Video is larger than ${state.maxUploadMb} MB.`; return; }

      submit.disabled = true; bar.hidden = false;
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/movies');
      xhr.setRequestHeader('Authorization', 'Bearer ' + state.token);
      xhr.upload.onprogress = ev => {
        if (!ev.lengthComputable) return;
        const pct = Math.round(ev.loaded / ev.total * 100);
        bar.value = pct; status.textContent = pct < 100 ? `Uploading… ${pct}%` : 'Processing…';
      };
      xhr.onerror = () => { err.textContent = 'Network error. Check your connection and try again.'; submit.disabled = false; bar.hidden = true; };
      xhr.onload = () => {
        let data = {}; try { data = JSON.parse(xhr.responseText); } catch {}
        if (xhr.status === 201) { toast('Movie published'); go('#/watch/' + data.movie.id); }
        else { err.textContent = data.error || 'Upload failed.'; submit.disabled = false; bar.hidden = true; status.textContent = ''; }
      };
      xhr.send(fd);
    } },
      h('div', { class: 'hint' }, `Formats: MP4 (H.264/AAC works everywhere), WebM, MOV. Up to ${state.maxUploadMb} MB.`),
      h('div', { class: 'field' }, h('label', { for: 'video' }, 'Video file'), h('input', { id: 'video', name: 'video', type: 'file', accept: 'video/mp4,video/webm,video/ogg,video/quicktime,.mp4,.webm,.ogv,.mov,.m4v', required: true })),
      h('div', { class: 'field' }, h('label', { for: 'poster' }, 'Poster image (optional)'), h('input', { id: 'poster', name: 'poster', type: 'file', accept: 'image/jpeg,image/png,image/webp' }), h('small', {}, 'Portrait 2:3 works best.')),
      h('div', { class: 'field' }, h('label', { for: 'title' }, 'Title'), h('input', { id: 'title', name: 'title', required: true, maxlength: 120 })),
      h('div', { class: 'row' },
        h('div', { class: 'field' }, h('label', { for: 'genre' }, 'Genre'),
          h('select', { id: 'genre', name: 'genre', required: true }, h('option', { value: '' }, 'Choose…'), state.genres.map(g => h('option', { value: g }, g)))),
        h('div', { class: 'field' }, h('label', { for: 'year' }, 'Year'), h('input', { id: 'year', name: 'year', type: 'number', min: 1888, max: thisYear + 1, placeholder: String(thisYear) }))),
      h('div', { class: 'field' }, h('label', { for: 'description' }, 'Description'), h('textarea', { id: 'description', name: 'description', maxlength: 2000 })),
      err, bar, status, submit);
    $main.replaceChildren(h('div', { class: 'panel wide' }, h('h1', {}, 'Upload a movie'), form));
    document.title = 'Upload – Jinx Movie Library';
  }

  async function adminPage() {
    if (!state.user || state.user.role !== 'admin') return fail('Only the administrator can open this page.');
    loading();
    const { users } = await api('/admin/users');
    const rows = users.map(u => {
      const isAdmin = u.role === 'admin';
      const label = isAdmin ? 'Administrator' : u.role === 'uploader' ? 'Can upload' : (u.requested ? 'Requested access' : 'Viewer');
      const act = isAdmin ? null : h('button', { class: u.role === 'uploader' ? 'btn danger' : 'btn primary', onclick: async e => {
        e.target.disabled = true;
        try { await api(`/admin/users/${u.id}/role`, { method: 'POST', json: { role: u.role === 'uploader' ? 'viewer' : 'uploader' } }); toast('Updated'); adminPage(); }
        catch (ex) { toast(ex.message); e.target.disabled = false; }
      } }, u.role === 'uploader' ? 'Remove upload access' : 'Approve upload access');
      return h('tr', {}, h('td', {}, u.name), h('td', {}, u.email), h('td', {}, label), h('td', {}, act));
    });
    $main.replaceChildren(h('h2', { class: 'sec' }, 'Upload permissions'),
      h('p', { class: 'meta' }, 'People asking for access appear first.'),
      h('div', { class: 'table-wrap' }, h('table', { class: 'users' },
        h('thead', {}, h('tr', {}, ['Name', 'Email', 'Status', ''].map(t => h('th', {}, t)))), h('tbody', {}, rows))));
    document.title = 'Admin – Jinx Movie Library';
  }

  // ---------- router ----------
  async function route() {
    renderHeader();
    const [path, qs] = (location.hash.slice(1) || '/').split('?');
    const params = new URLSearchParams(qs || '');
    const parts = path.split('/').filter(Boolean);
    window.scrollTo(0, 0);
    try {
      if (!parts.length) await home(params);
      else if (parts[0] === 'watch' && parts[1]) await watch(parts[1]);
      else if (parts[0] === 'login') authPage('login');
      else if (parts[0] === 'register') authPage('register');
      else if (parts[0] === 'upload') uploadPage();
      else if (parts[0] === 'mine') await mine();
      else if (parts[0] === 'admin') await adminPage();
      else fail('That page does not exist.');
    } catch (e) { fail(e.message); }
  }

  async function init() {
    try { const c = await api('/config'); state.genres = c.genres; state.maxUploadMb = c.maxUploadMb; if (c.adminName) document.getElementById('foot-admin').textContent = 'Administrator: ' + c.adminName; } catch {}
    if (state.token) { try { state.user = (await api('/auth/me')).user; } catch { state.token = null; } }
    window.addEventListener('hashchange', route);
    route();
  }
  init();
})();
